DROP TABLE IF EXISTS user;
CREATE TABLE user(user_id INT PRIMARY KEY AUTO_INCREMENT, user_name VARCHAR(100), word_id INT, last_picked_date datetime);
 
DROP TABLE IF EXISTS word;
CREATE TABLE word(word_id INT PRIMARY KEY AUTO_INCREMENT, word_phrase VARCHAR(25),
			word_sentence VARCHAR(255)
);