INSERT INTO user(user_id,user_name,word_id,last_picked_date) VALUES(12,'Tom',0,'Jan 01 1900');
INSERT INTO user(user_id,user_name,word_id,last_picked_date) VALUES(22,'Jerry',0,'Jan 01 1900');
INSERT INTO user(user_id,user_name,word_id,last_picked_date) VALUES(32,'Jack',0,'Jan 01 1900');
INSERT INTO user(user_id,user_name,word_id,last_picked_date) VALUES(42,'Feddy',0,'Jan 01 1900');


INSERT INTO word(word_id,word_phrase, word_sentence) VALUES(11,'Happiness', 'There is only one happiness in this life, to love and be loved.');
INSERT INTO word(word_id,word_phrase, word_sentence) VALUES(22,'Sadness', 'A sad soul can kill quicker than a germ');
INSERT INTO word(word_id,word_phrase, word_sentence) VALUES(33,'Anger', 'Anger is an acid that can do more harm to the vessel in which it is stored than to anything on which it is poured.');
INSERT INTO word(word_id,word_phrase, word_sentence) VALUES(44,'Fear', 'To conquer fear is the beginning of wisdom.');